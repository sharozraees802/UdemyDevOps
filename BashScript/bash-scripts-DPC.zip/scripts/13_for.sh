#!/bin/bash

for VAR1 in java .net python ruby php
do
  echo "Looping....."
  sleep 1
  echo "###################################################"
  echo "Value of VAR1 is $VAR1."
  echo "###################################################"
  date
  echo
done
